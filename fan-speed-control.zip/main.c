
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

 

int main()
{
int age = 0;
int *p_int;
p_int = &age;

while(*p_int < 21) {
    printf("%d\n", *p_int);
    ++(*p_int);
}
    

    return 0;
}